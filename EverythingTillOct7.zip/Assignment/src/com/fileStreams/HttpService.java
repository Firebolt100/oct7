package com.fileStreams;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class HttpService {
public static void main(String[] args) throws IOException {
	
	int port = 80;
	
	ServerSocket service = new ServerSocket(port);
	
	System.out.println("waiting for connection");
	
	Socket clientinfo = service.accept(); // for service to create a socket for a client
	
	System.out.println(clientinfo);
	
	InputStream in = clientinfo.getInputStream();
	
	InputStreamReader bridge = new InputStreamReader(in);
	BufferedReader bReader = new BufferedReader(bridge);
	
	while(true){
		String line = bReader.readLine();
		
		if(line == null)
			break;

		System.out.println(line);
		
		PrintWriter p = new PrintWriter(clientinfo.getOutputStream());
		p.println("Hello world ");
		p.flush();
		p.close();
	}
	
	
}
}
