package com.fileStreams;

import java.io.FileNotFoundException;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class Q5 {
	public static void main(String[] args) {
	
		InputStreamReader in = new InputStreamReader(System.in);
		String fileName = "test.txt";
		PrintWriter out =null;
		try {
			out = new PrintWriter(fileName);
		} catch (FileNotFoundException e1) {
			
			e1.printStackTrace();
		}
		
		//to write in text file. fileoutputStream will write in binary
		
		char store = 'a' ;
		
		while(store!='~')
		{
			try {
				store=(char)in.read();
				
				if(Character.isLetter(store))
				{
					if(Character.isLowerCase(store))
						{	store=Character.toUpperCase(store);
							out.print(store);
						}
					else
						if(Character.isUpperCase(store))
						{	store = Character.toLowerCase(store);
							out.print(store);
						}
						
				}
				else if(Character.isDigit(store))
					{	store='*';
						out.print(store);
					}
				else if(store=='~') {
						out.close();
					}
				else
				  out.print(store);
				
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		try {
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
}
}
