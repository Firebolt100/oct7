package com.fileStreams;

import java.io.File;
import java.util.Scanner;

public class Q4 {

	public static void main(String[] args) {
		
		File f = new File(args[0]);
		
		if(f.isDirectory()){
			File [] listOfFiles = f.list();
			for(String temp : a){
				System.out.println(temp);
			}
			
			System.out.println("No. of files in this directory  :"+a.length);
			
			for(String temp : a){
				if(f.isFile())
				
			}
			int i=0;
			
			System.out.println("Do you want to delete .txt files ?");
			Scanner s = new Scanner(System.in);
			String option= s.next();
			
			if(option.equalsIgnoreCase("yes")){
				while(i<a.length)
				{	File fin=new File(a[i]) ;
					if(a[i].equals("*.txt"))
							fin.delete();
				}
			}
		
	}
}
}
