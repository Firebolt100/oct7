package com.chat;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) throws UnknownHostException, IOException {
		
		
		//Socket client = new Socket();
		System.out.println("In client");
		Socket server = new Socket("10.102.49.138",90);
		System.out.println(server.isConnected());
		//client.connect(server.getLocalSocketAddress());
		
		InputStreamReader in = new InputStreamReader(server.getInputStream());
		BufferedReader br=new BufferedReader(in) ;
		PrintWriter pw= new PrintWriter(server.getOutputStream(), true);
	
	try{
	while(true)
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter msg ");
		
		String msgIn=scanner.nextLine();
		
		pw.println(msgIn);
	
		
		String x=br.readLine() ;
		System.out.println("Server :"+x);
	
		
	}
	}
	finally
	{
		pw.close();
		br.close();
	}

//	br.close();

	}
}
