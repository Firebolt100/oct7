package com.chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class ChatClient extends Thread{
	
	Socket server = new Socket("10.102.49.138",90);
	
	synchronized public void read() throws IOException{
		InputStream in= null;
		in = server.getInputStream();
		InputStreamReader isr = new InputStreamReader(in);
		BufferedReader bfr = new BufferedReader(isr);
		System.out.println("Server :" + bfr.readLine()  );
		
	}
	
	synchronized public void reply() throws IOException{
		OutputStream out = server.getOutputStream();
		PrintWriter pw = new PrintWriter(out, true);
		
		System.out.println("You : ");
		Scanner msg = new Scanner(System.in);
		pw.println(msg.nextLine());
		
	}
	public void run(){
		try {
			read();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			reply();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	public static void main(String[] args) throws UnknownHostException, IOException {
		
		ChatClient you = new ChatClient();
		
		
	
}
}
