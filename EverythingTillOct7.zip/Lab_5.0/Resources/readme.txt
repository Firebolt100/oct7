Objective:
-------------

To understand jsp scripting elements.
To read http request parameters using JSP.

Existing resources:
--------------------------------

1.categories.html:-							This page will display product categories.
2.bookCatelogue.jsp:-						This page will display book catalogue.  

Update following resources:
------------------------------------

1.displayProductDetails.jsp:-			This jsp should read products selected by web-client from bookCatelogue.html and 
												display them in tabular format as html response to the web client.
												

Note:
-------

Please, do not make changes in EXISTING RESOURCES.



														