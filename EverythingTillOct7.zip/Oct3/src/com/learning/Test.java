package com.learning;

interface I{
	
	default void print(){
		System.out.println("DEFAULT here !");
	}
}

 class A implements I {

	public void print(){
		
		I.super.print();//to use both the methods
		System.out.println("inside A printing");
	}
}
public class Test{
	public static void main(String[] args) {
		
		I obj = new A();
		obj.print(); // if A doesnt hav an overriden print then obj.print() will take the default print() of interface
		
		
	}
}
