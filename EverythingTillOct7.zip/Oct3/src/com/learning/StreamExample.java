package com.learning;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class StreamExample {

	public static void main(String[] args) {
		
	
	//in linked list multiple duplicates and null are allowed
	//ll is ordered
	
	LinkedList<String> l = new LinkedList<>();
	
	l.add("a");
	l.add("");
	l.add("");
	l.add("b");
	
	System.out.println(l);
	
	for(String s : l){//business logic
		}
	
	
	List<String> filtered = l.stream().filter(string -> !string.isEmpty()).collect(Collectors.toList());
	System.out.println("Filtered List: " + filtered);
	}
	
}
