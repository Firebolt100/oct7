package com.learning;

interface MathOperations{
	int operation(int a,int b);
		
	
}

public class LambdaExpression {

	public static void main(String[] args) {
		
		//Annonymous Class
		MathOperations m = new MathOperations() {
			
			@Override
			public int operation(int a, int b) {
				
				return (a+b);
			}
		};
		
		//Same functionality achieved using Lambda expression (implementing anonymous class easily)
		
		MathOperations m1 =(int a , int b)->{
			return (a+b);
		};
		
		MathOperations m2 = (a,b)->(a+b); //even if types of arguments isnt mentioned it is ok if there is only one method . can skip the curly braces if there is only one single expression
		
		
		
	}
}
