package com.learning;

public class RunnableDemo {

	public static void main(String[] args) {
		
		Runnable r = new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println(Thread.currentThread().getName());
				
			}		
		};
		
		Thread t = new Thread(r);
		t.start();
		
		Runnable r2 = ()->System.out.println(Thread.currentThread().getName());
	  new Thread(r2,"mythread").start(); // is same as Thread t2 = newThread(r2,"mythread"); t2.start();
	 
	 
	}
}
