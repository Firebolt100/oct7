package com.barclays;

public class Conflicts {

}
