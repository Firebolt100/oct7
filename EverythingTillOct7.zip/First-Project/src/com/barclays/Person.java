package com.barclays;

public class Person {

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	private String name;
	private int age;
	private static int count;

	public Person() {
		name= "Not Available";
		age= 18;		
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}
	
	public static int getCount(){
		return Person.count;
	}
}
