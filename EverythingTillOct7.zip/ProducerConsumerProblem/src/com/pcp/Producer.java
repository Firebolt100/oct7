package com.pcp;

public class Producer extends Thread {

	private Container box;
	
	Producer(Container box){
		this.box = box;
	}
	
	public void run(){
		box.put();
		
	}
	
}
