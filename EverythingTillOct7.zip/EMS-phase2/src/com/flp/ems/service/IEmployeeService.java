package com.flp.ems.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import com.flp.ems.domain.Employee;

public interface IEmployeeService {

	public void AddEmployee(HashMap<String , String > h) throws FileNotFoundException, SQLException, IOException;
	public void ModifyEmployee(HashMap<String , String > h) throws SQLException, IOException;
	public boolean RemoveEmployee(HashMap<String , String > h) throws SQLException;
	public HashMap<String , String> SearchEmployee(HashMap<String , String > h) throws SQLException;
	public HashMap<String,String>[] getAllEmployee() throws SQLException;
}
